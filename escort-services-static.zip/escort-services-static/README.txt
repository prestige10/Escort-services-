Escort Services UK - static HTML + CSS version
================================================

Open index.html in a browser, or upload this whole folder to any web host
(cPanel, Netlify, GitHub Pages, S3, etc.). No build step or server code needed.

Folder layout
- index.html, about.html, contact.html, blog.html, escort-services.html, escort-jobs.html,
  privacy.html, terms.html, 404.html
- escort-services/<city>.html, escort-jobs/<city>.html, blog/<post>.html
- css/style.css   - the site's full design (colours, fonts, layout)
- css/static.css  - pure-CSS replacements for menus, tabs, FAQ, flip cards, reviews
- images/         - all photos and logos

Works without JavaScript
- Header Services/Careers menus open on hover or keyboard focus
- Mobile menu opens with the menu icon
- FAQ answers open on click; contact page tabs switch on click
- Reviews scroll sideways; service and companion cards flip on hover or tap

Forms
- Booking, job application and Join Our Team forms post straight to Formspree
  (form xeozlkad). After sending, visitors see Formspree's thank-you page.

Search engines
- Each page keeps its title, description, canonical link and structured data,
  pointing at https://escortservices.co.uk
